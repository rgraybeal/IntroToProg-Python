#-------------------------------------------------#
# Title: Working with Dictionaries
# Dev:   RRoot
# Date:  Sept 16, 2017
# ChangeLog: (Who, When, What)
#   RRoot, 09/16/2017, Created Script
#   RGraybeal, 8/20/18, Rearranged code, added classes x2, rolled
#   code into functions, adjusted functions to work in new form

#-------------------------------------------------#

#-- Data --#
# declare variables and constants
# objFile = An object that represents a file
# strData = A row of text data from the file
# dicRow = A row of data separated into elements of a dictionary {Task,Priority}
# lstTable = A dictionary that acts as a 'table' of rows
# strMenu = A menu of user options
# strChoice = Capture the user option selection


#-- Input/Output --#
# User can see a Menu (Step 2)
# User can see data (Step 3)
# User can insert or delete data(Step 4 and 5)
# User can save to file (Step 6)
#-- Processing --#
# Step 1
# When the program starts, load the any data you have
# in a text file called ToDo.txt into a python Dictionary.

# Step 2
# Display a menu of choices to the user

# Step 3
# Display all todo items to user

# Step 4
# Add a new item to the list/Table

# Step 5
# Remove a new item to the list/Table

# Step 6
# Save tasks to the ToDo.txt file

# Step 7
# Exit program
#-------------------------------
objFileName = "./Todo.txt"
strData = ""
dicRow = {}
lstTable = []

# Step 1
# When the program starts, load the any data you have
# in a text file called ToDo.txt into a python Dictionary.

class FileManagement(object):

    @staticmethod
    def createNewFile():
        """
        :desc : This function creates a new file prepopulated with required entries
        :param : parameters are empty
        :param :
        :type  :
        :type :
        :rtype: is a file
        """
        txtTodo = open(objFileName, "w")
        txtTodo.write("Clean House,low\n")
        txtTodo.write("Pay Bills,high\n")
        txtTodo.close()

    @staticmethod
    def createDicAndList():
        """
        :desc :This method reads the file and creates a dictionary and list
        :param : objFileName defined in data section
        :param :
        :type  :str
        :type :
        :rtype: None, dictionary and list of dictionary rows
        """
        objFile = open(objFileName, "r")
        for line in objFile:
            strData = line.split(",") # readline() reads a line of the data into 2 elements
            dicRow = {"Task":strData[0].strip(), "Priority":strData[1].strip()}
            lstTable.append(dicRow)
        objFile.close()

# Step 2
# Display a menu of choices to the user
#Create a class containing the functions listed in the menu
class MenuSelections(object):
    #1. display menu
    @staticmethod
    def showMenu():
        """
        :desc : Show a menu to the user and ask for input
        :param : user input as a string
        :param :
        :type  :string
        :type :
        :rtype: None
        """
        print("""
                Menu of Options
                1) Show current data
                2) Add a new item.
                3) Remove an existing item.
                4) Save Data to File
                5) Exit Program
                """)
        strChoice = str(input("Which option would you like to perform? [1 to 4]  - "))
        print()  # adding a new line

# Step 3
# Display all todo items to user
    @staticmethod
    def displayCurrent():
        """
        :desc : This function displays the current ToDo list
        :param : lstTable rows
        :param :
        :type  :string
        :type :
        :rtype: string
        """
        print("******* The current items ToDo are: *******")
        for row in lstTable:
            print(row["Task"] + "(" + row["Priority"] + ")")
        print("*******************************************")

# Step 4
# Add a new item to the list/Table
    @staticmethod
    def addItem():
        """
        :desc :This function allows the user to add an item to the list. Internally, updates both the dictionary and the list
        :param : strTask from user
        :param : strPriority from user
        :type  :str
        :type : str
        :rtype: dictionary row, list table
        """
        strTask = str(input("What is the task? - ")).strip()
        strPriority = str(input("What is the priority? [high|low] - ")).strip()
        dicRow = {"Task": strTask, "Priority": strPriority}
        lstTable.append(dicRow)
        print("Current Data in table:")
        for dicRow in lstTable:
            print(dicRow)

        # 4a Show the current items in the table
        print("******* The current items ToDo are: *******")
        for row in lstTable:
            print(row["Task"] + "(" + row["Priority"] + ")")
        print("*******************************************")
        MenuSelections.showMenu()  # to show the menu
        #continue  # to show the menu

# Step 5
# Remove a new item to the list/Table
    @staticmethod
    def removeItem():
        """
        :desc :This function allows the user to remove a task. Error checks for task not in list. Prints current items
        :param : strKeytoRemove
        :param :
        :type  :str
        :type :
        :rtype: None
        """
        # 5a-Allow user to indicate which row to delete
        strKeyToRemove = input("Which TASK would you like removed? - ")
        blnItemRemoved = False  # Creating a boolean Flag
        intRowNumber = 0
        while (intRowNumber < len(lstTable)):
            if (strKeyToRemove == str(
                    list(dict(lstTable[intRowNumber]).values())[0])):  # the values function creates a list!
                del lstTable[intRowNumber]
                blnItemRemoved = True
            # end if
            intRowNumber += 1
        # end for loop
        # 5b-Update user on the status
        if (blnItemRemoved == True):
            print("The task was removed.")
        else:
            print("I'm sorry, but I could not find that task.")
        # 5c Show the current items in the table
        print("******* The current items ToDo are: *******")
        for row in lstTable:
            print(row["Task"] + "(" + row["Priority"] + ")")
        print("*******************************************")
        MenuSelections.showMenu()  # to show the menu

# Step 6
# Save tasks to the ToDo.txt file
    @staticmethod
    def SaveToFile():
        """
        :desc : Asks user if want to save file, writes dictionary rows line by line with formatting
        :param : user input as string
        :param :
        :type  :str
        :type :
        :rtype: None
        """
        print("******* The current items ToDo are: *******")
        for row in lstTable:
            print(row["Task"] + "(" + row["Priority"] + ")")
        print("*******************************************")
        # 5b Ask if they want save that data
        if ("y" == str(input("Save this data to file? (y/n) - ")).strip().lower()):
            objFile = open(objFileName, "w")
            for dicRow in lstTable:
                objFile.write(dicRow["Task"] + "," + dicRow["Priority"] + "\n")
            objFile.close()
            input("Data saved to file! Press the [Enter] key to return to menu.")
        else:
            input("New data was NOT Saved, but previous data still exists! Press the [Enter] key to return to menu.")
        #MenuSelections.showMenu()  # to show the menu


def main():
    """
    :desc : This function calls the other functions to run the program
    :param :user input for menu option
    :param :
    :type  :str
    :type :
    :rtype:None
    """
    FileManagement.createNewFile()
    FileManagement.createDicAndList()

    print("\n\n************************************************************")
    print("***Welcome to the TODO list***")
    print("**This program helps you organize your efforts in a to do list**")
    print("****************************************************************")
    while (True):
        print("""
       Menu of Options
        1) Show current data
        2) Add a new item.
        3) Remove an existing item.
        4) Save Data to File
        5) Exit Program
        """)
        strChoice = str(input("Which option would you like to perform? [1 to 4] - "))
        print()  # adding a new line

        if (strChoice.strip() == '1'):
            MenuSelections.displayCurrent()

        elif (strChoice.strip() == '2'):
            MenuSelections.addItem()

        elif (strChoice == '3'):
            MenuSelections.removeItem()

        elif (strChoice == '4'):
            MenuSelections.SaveToFile()
# Step 7
# Exit program - no function developed here due to simplicity of step.
        elif (strChoice == '5'):
            break

#call the method
main()

#--------------------------------------------------------------#
